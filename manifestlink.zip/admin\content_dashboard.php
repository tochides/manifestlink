<section>
    <h2 style="color:#3b82f6; text-align:center; margin-bottom:24px;">Admin Dashboard</h2>
    <div class="info-box">
        <p class="info-title">Welcome to the ManifestLink Admin Panel.</p>
        <p class="info-desc">Use the sidebar to manage users, QR codes, and OTP verifications.</p>
    </div>
</section> 